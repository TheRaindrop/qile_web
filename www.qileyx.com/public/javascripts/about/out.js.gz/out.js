$(function(){$(".head_nav .inav a.active").removeClass("active");$(".head_nav .inav a.about").addClass("active")});
